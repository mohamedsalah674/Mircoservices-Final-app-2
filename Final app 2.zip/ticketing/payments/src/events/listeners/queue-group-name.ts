export const queueGroupName = 'payments-service';
